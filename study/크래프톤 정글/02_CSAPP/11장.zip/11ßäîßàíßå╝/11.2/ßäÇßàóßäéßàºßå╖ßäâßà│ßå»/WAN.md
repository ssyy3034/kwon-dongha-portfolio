**WAN(Wide Area Network)** 은 [[LAN]]보다 더 넓은 지리적 영역을 포괄하는 **광역 통신망**입니다. CS:APP 11장에서는 고속의 점대점(point-to-point) 전화 연결을 WAN의 한 예시로 들고 있습니다.

[[라우터]]는 이러한 WAN들을 다른 [[LAN]]이나 [[WAN]]과 연결하여 [[internet]]을 구성하는 데 사용될 수 있습니다.